import java.util.ArrayList;
import java.util.Random;

public class Hand {

    ArrayList<Card> cards_in_hand = new ArrayList<Card>();

    public Hand(Deck deck) {
        pick_card(deck);
        pick_card(deck);
    }

    public void pick_card(Deck deck) {
        Random num = new Random();
        boolean used;
        Card to_append;

        do {
            int card_value = num.nextInt(52);
            to_append = deck.card_deck.get(card_value);
            used = !to_append.card_avail;
        } while(used);

        cards_in_hand.add(to_append);
        to_append.card_avail = false;

        Card.print_image(to_append.card_image_name);
    }

    public int sum_of_cards() {

        int sum_of_cards = 0;

        for (Card card : cards_in_hand) {
            sum_of_cards += card.card_value;
        }
        return sum_of_cards;
    }

    public boolean hand_overflow() {
        return sum_of_cards() > 21;
    }

    public String toString() {

        String cards_in_deck = "";

        for (Card card : cards_in_hand) {
        	
        	String card_real = "";
        	
            switch (card.card_value) {
            
            case 1:
            	card_real = ("Ace");
                break;
            case 2:
            	card_real = ("Two");
                break;
            case 3:
            	card_real = ("Three");
                break;
            case 4:
            	card_real = ("Four");
                break;
            case 5:
            	card_real = ("Five");
                break;
            case 6:
            	card_real = ("Six");
                break;
            case 7:
            	card_real = ("Seven");
                break;
            case 8:
            	card_real = ("Eight");
                break; 
            case 9:
            	card_real = ("Nine");
                break;
            case 10:
            	card_real = ("Ten");
                break;
            case 11:
            	card_real = ("Jack");
                break;
            case 12:
            	card_real = ("Queen");
                break;
            case 13:
            	card_real = ("King");
                break;
        }

        	
            cards_in_deck += (card_real + " of " + card.card_suit + " - ");
        }

        cards_in_deck = cards_in_deck.substring(0, (cards_in_deck.length() - 2));

        return cards_in_deck;
    }
}
