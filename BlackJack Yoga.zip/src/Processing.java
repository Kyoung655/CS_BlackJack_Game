import java.util.Scanner;
import processing.core.*;

public class Processing extends PApplet{    	
	
    public static void main(String[] args) {
    	PApplet.main("Processing");
    	
    	
    }
 
	PImage gold_plate;
	PImage back_of_card;
	PImage random_card;

	// total number of images
	int num = 10;
	int numImages = 3;
	// an array of images
	PImage[] images = new PImage[num];

	PFont f;

	boolean boxClicked = false;
	boolean locked = false;

	int randomNumber;
	
	
	public void settings() {
		
	  //creates the size of the screen and makes the background dark red
	  size(900,900);
	}
	
	public void setup()
	{
		
	  background(100,0,0);
	  noStroke();

	  //loads the gold plate image and sets the font
	  gold_plate = loadImage("gold_plate.jpg");
	  back_of_card = loadImage("back_of_card.png");
	  
	  //error
	  for (int i = 1; i < numImages; i++)
	  {
	    images[i] = loadImage((i) + "c.png");
	  }
	  
	  //random_card = loadImage("");
	  f = createFont("Arial",16,true);
	  
	}

	
	
    int total_money = 1000;
    int bet_amount = 50;
    
    int Rounds_Played = 0;
    
    Deck regular = new Deck();
    Hand computer = new Hand(regular);
    Hand player = new Hand(regular);
    
    
    boolean player_won = true;
    boolean computer_won = true;

    boolean player_turn = true;
    boolean computer_turn = true;
    
    
    
	
	//creates lines by following the mouse
	public void draw() {
		
  	  //Gold marble image 
  	  image(gold_plate, 670, 320, 200, gold_plate.height/4);
  	  
  	  //Back of playing card image
  	  image(back_of_card, 150, 150, 150, gold_plate.height/5);
  	  
  	  
  	  //First Rectangle ("Hit")
  	  fill(248, 215, 140);
  	  if (mouseX >= 686 && mouseX <= 856 && mouseY >= 350 && mouseY <= 413) 
  	  {
  	  rect(686, 350, 170, 63);
  	  boxClicked = true; 
  	  } 
  	  else
  	  {
  	    fill(210,173,93);
  	    rect(686, 350, 170, 63);
  	  }
  	  
  	  
  	  
  	  //Second rectangle (Stand)
  	  fill(248, 215, 140);
  	  if (mouseX >= 686 && mouseX <= 856 && mouseY >= 505 && mouseY <= 568) 
  	  {
  	  rect(686, 505, 170, 63);
  	  boxClicked = true; 
  	  } 
  	  else
  	  {
  	   fill(210,173,93);
  	   rect(686, 505, 170, 63);
  	  }
  	  
  	  
  	  //Hit and Stand text
  	  textFont(f,36);
  	  fill(0);
  	  text("Hit",750,395);
  	  text("Stand",725,550);
  	  
  	  
  	  
  	  //Display's Dealer's info
  	  textFont(f,20);
  	  fill(255);
	  text("Dealer Total: ", 150, 100); 
	  text("Dealer Hand: ", 150, 130); 
  	  
  	  
  	  
  	  //Displays the bet
  	  textFont(f,35);
  	  fill(2232, 188, 102);
  	  text("Bet: $" + bet_amount, 150, 430); 
  	  
  	  
  	  
  	  //Displays human's info 
  	  textFont(f,20);
  	  fill(255);
  	  text("Player Total: " + player.sum_of_cards(), 150, 660); 
  	  text("Current Hand: " + player, 150, 690); 
  	  text("Total Funds: $" + total_money, 150, 720);
  	   
  	   
  	   
  	  //Displays the number of levels played and the goal
  	  textFont(f,20);
  	  fill(232, 188, 102);
  	  text("Rounds Played: " + Rounds_Played, 150, 790); 
  	  text("Goal: $ 5000", 150, 820); 
  	  
  	  //Displays "BLACKJACK"
  	  textFont(f,60);
  	  fill(232, 188, 102);
  	  text("B\nL\nA\nC\nK\nJ\nA\nC\nK", 20, 100); 
        
}

	public void mousePressed()
	{
	  
	  //displays the word "hit"
	  if (mouseX >= 686 && mouseX <= 856 && mouseY >= 350 && mouseY <= 413)
	  {
		  
		  background(100,0,0);
		  
		  player_won = !player.hand_overflow(); // If looses from the start
		  
	        if (player.hand_overflow()) {
	            player_won = false;
	            player_turn = false;
	            
	            //Displays the winner
	            fill(179,30,60);
	            rect(150, 500, 200, 90); //x,y,l,h
	            
	        	//Displays the winner
	        	textFont(f,35);
	        	fill(255,255,255);
	        	text("OVER 21", 175, 560); 
	        	
        	  /* //BUST!
        	  //if condition --> if [player busts] execute this:
        	  fill(210,100,93);
        	  rect(250, 250, 400, 300); //x,y,l,h
        	  fill(0);
        	  text("BUST!",360, 420); */

	            
	        }
	        
	        
	        if (!player.hand_overflow()) {
	        	player.pick_card(regular);
	        }
	        
		  
	  	  //Displays human's info 
	  	  textFont(f,20);
	  	  fill(255);
	  	  text("Player Total: " + player.sum_of_cards(), 150, 660); 
	  	  text("Current Hand: " + player, 150, 690); 
	  	  text("Total Funds: $" + total_money, 150, 720);
		  
	    //text("Hit", random(0,900),random(0,900));
	    //randomNumber = (int)random(numImages);
	    
	  }
	  
	  //displays the word "stand"
	  else if (mouseX >= 686 && mouseX <= 856 && mouseY >= 505 && mouseY <= 568) 
	  {
		  
	    player_turn = false;
		  
        while (computer.sum_of_cards() <= 16) {
            	computer.pick_card(regular);
            }
       
        
	        background(100,0,0);
	        
			  //Display's Dealer's info
			  textFont(f,20);
			  fill(255);
			  text("Dealer Total: " + computer.sum_of_cards(), 150, 100); 
			  text("Dealer Hand: " + computer, 150, 130); 
			  //text("Total Funds: $" + total_money, 150, 720);
		  
	        if (player.sum_of_cards() > 21) {
	            //System.out.println("PLAYER LOST");
	            total_money -= bet_amount;
	            
	            //Displays the winner
	            fill(179,30,60);
	            rect(150, 500, 280, 90); //x,y,l,h
	            
	        	  //Displays the winner
	        	  textFont(f,35);
	        	  fill(255,255,255);
	        	  text("  YOU LOST  ", 175, 560); }
	        	  
	        	  
        	  else if (computer.sum_of_cards() > 21) {
  	            //System.out.println("PLAYER WON");
  	            total_money += bet_amount;
  	            
  	            //Displays the winner
  	            fill(19,139,67);
  	            rect(150, 500, 280, 90); //x,y,l,h
  	            
  	        	  //Displays the winner
  	        	  textFont(f,35);
  	        	  fill(255,255,255);
  	        	  text("  YOU WON!  ", 175, 560); 
        		 }
	        	  
	        	  
			  
	       
	        else if ((computer.sum_of_cards() > player.sum_of_cards()) && (computer_won)) {
	            //System.out.println("PLAYER LOST");
	            total_money -= bet_amount;
	            
	            //Displays the winner
	            fill(179,30,60);
	            rect(150, 500, 280, 90); //x,y,l,h
	            
	        	  //Displays the winner
	        	  textFont(f,35);
	        	  fill(255,255,255);
	        	  text("  YOU LOST  ", 175, 560); 
	            
			  
	        }
	        else if ((computer.sum_of_cards() == player.sum_of_cards()) && (computer_won)) {
	            //System.out.println("DRAW!");
	            total_money += (bet_amount/2); // NOT SURE ABOUT THIS
	            
	            //Displays the winner
	            fill(37, 210, 173);
	            rect(150, 500, 280, 90); //x,y,l,h
	            
	        	  //Displays the winner
	        	  textFont(f,35);
	        	  fill(255,255,255);
	        	  text("    DRAW    ", 175, 560); 
	            
			  
	        }
	        else {
	            //System.out.println("PLAYER WON");
	            total_money += bet_amount;
	            
	            //Displays the winner
	            fill(19,139,67);
	            rect(150, 500, 280, 90); //x,y,l,h
	            
	        	  //Displays the winner
	        	  textFont(f,35);
	        	  fill(255,255,255);
	        	  text("  YOU WON!  ", 175, 560); 

	            
	        }
	        
	      	  Rounds_Played += 1;
	    	  
	      	  //Displays the number of levels played and the goal
	      	  textFont(f,20);
	      	  fill(232, 188, 102);
	      	  text("Rounds Played: " + Rounds_Played, 150, 790); 
	      	  text("Goal: $ 5000", 150, 820); 
	        //System.out.println(regular); // Prints entire deck	  
		  
	    //text("Stand", random(0,900),random(0,900));
	  }
	}


	public void mouseReleased() {
	  locked = false;
	}
}