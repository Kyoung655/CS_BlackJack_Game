/*import java.util.*;

public class Running {   
	
    public static void run() {
    	
        int total_money = 1000;
        int bet_amount = 0;
    		
        Scanner input = new Scanner(System.in); // SHOULD NOT NEED THIS IN FOR PROCESSING

        System.out.print("Would you like to bet: "); // CHANGE THIS TO THE KEYS IN PROCESSING
                                                     // (FOR FINAL NEED TO CHECK THAT PLAYER HAS ENOUGH MONEY TO BET THAT AMOUNT!!)
        bet_amount = input.nextInt();
        input.nextLine(); // Resets Scanner

        Deck regular = new Deck();

        Hand computer = new Hand(regular);
        System.out.println("Computer: " + computer + " Sum: " + computer.sum_of_cards());

        Hand player = new Hand(regular);
        System.out.println("Player: " + player + " Sum: " + player.sum_of_cards());

        System.out.println();
        System.out.println(regular); // Prints entire deck

        boolean player_won = true;
        boolean computer_won = true;

        boolean player_turn = true;
        boolean computer_turn = true;

        // PLAYERS TURN

        while (player_turn) {


            System.out.println("Player: " + player + " Sum: " + player.sum_of_cards());

            System.out.print("Would you like to draw another card? (y/n): "); // CHANGE THIS TO THE HIT OR STAND CLICK IN PROCESSING
            String draw_card = input.nextLine();

            if (draw_card.equals("y")) {
                player.pick_card(regular);
            }

            else if (draw_card.equals("n")) {
                player_turn = false;
            }

            if (player.hand_overflow()) {
                player_won = false;
                player_turn = false;
            }
        }

        // DEALERS TURN


        while (computer.sum_of_cards() <= 16) {
            computer.pick_card(regular);
            }

        if (computer.hand_overflow()) {
            computer_won = false;
        }

        System.out.println(regular); // Prints entire deck

        System.out.println("Player: " + player + " Sum: " + player.sum_of_cards());
        System.out.println("Computer: " + computer + " Sum: " + computer.sum_of_cards());

        if ((!player_won)) {
            System.out.println("PLAYER LOST");
            total_money -= bet_amount;
        }
        else if ((computer.sum_of_cards() > player.sum_of_cards()) && (computer_won)) {
            System.out.println("PLAYER LOST");
            total_money -= bet_amount;
        }
        else if ((computer.sum_of_cards() == player.sum_of_cards()) && (computer_won)) {
            System.out.println("DRAW!");
            total_money += (bet_amount/2); // NOT SURE ABOUT THIS
        }
        else {
            System.out.println("PLAYER WON");
            total_money += bet_amount;
        }

        System.out.println("Total Money: " + total_money);
        
    }
} */