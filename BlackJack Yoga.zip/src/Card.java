import java.util.ArrayList;
import java.util.Random;

public class Card {

    int card_value;
    String card_suit;
    String card_name;
    String card_image_name;
    Boolean card_avail = true;

    public Card (int number, String suit) {

        card_value = number;
        card_suit = suit;
        card_name = card_name(card_value, card_suit);
        card_image_name = card_image_name(card_name);
    }

    public Card () {
        card_value = card_value();
        card_suit = card_suit();
        card_name = card_name(card_value, card_suit);
        card_image_name = card_image_name(card_name);
    }

    public static int card_value() {
        Random num = new Random();
        int card_value = (num.nextInt(12) + 1);

        return card_value;
    }

    public static String card_suit() {
        Random num = new Random();
        int suit_value = num.nextInt(4);

        String suit = "";

			// USE THIS TO DRAW IMAGES
        switch (suit_value) {
            case 0:
                suit = ("c");
                break;
            case 1:
                suit = ("d");
                break;
            case 2:
                suit = ("h");
                break;
            case 3:
                suit = ("s");
                break;
    }

        return suit;
    }

    public static String card_name(int card_value, String card_suit) {

        String card_name = String.valueOf(card_value) + card_suit;
        return card_name;
    }

    public static String card_image_name(String card_name) {
        String card_image_name = card_name + ".png";
        return card_image_name;
    }

    public static boolean print_image(String card_image_name) {

        // ADD IN GRAPHICS CODE TO DRAW THE IMAGE IN PROCESSING (account for root to the print the image)

        return true;
    }

    public String toString() {
        return card_name;
    }
}
