import java.util.ArrayList;

public class Deck {

    ArrayList<Card> card_deck = new ArrayList<Card>(52);

    public Deck () {
        reset_deck (card_deck);
    }

    public static void reset_deck (ArrayList cards_left) {
        cards_left.clear();
/*// USE IF DRAWING IMAGES
        for (int i = 1; i <= 13; i++) {
            Card new_club = new Card(i, "c");
            cards_left.add(new_club);

            Card new_diamond = new Card(i, "d");
            cards_left.add(new_diamond);

            Card new_hearts = new Card(i, "h");
            cards_left.add(new_hearts);

            Card new_spade = new Card(i, "s");
            cards_left.add(new_spade);
        } */
        
        
        for (int i = 1; i <= 13; i++) {
            Card new_club = new Card(i, "Clubs");
            cards_left.add(new_club);

            Card new_diamond = new Card(i, "Diamonds");
            cards_left.add(new_diamond);

            Card new_hearts = new Card(i, "Hearts");
            cards_left.add(new_hearts);

            Card new_spade = new Card(i, "Spades");
            cards_left.add(new_spade);
        }
    }

    public String toString() {

        String cards_in_deck = "DECK: \n";

        for (Card card : card_deck) {
            cards_in_deck += (card + ", ");
            cards_in_deck += (card.card_avail + "\n");
        }

        return cards_in_deck;
    }
}
